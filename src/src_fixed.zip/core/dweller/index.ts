// Dweller management modules
export { DwellerStatsManager } from './DwellerStatsManager';
export { DwellerHealthManager } from './DwellerHealthManager';
export { DwellerEquipmentManager } from './DwellerEquipmentManager';
export { DwellerAppearanceManager } from './DwellerAppearanceManager';
export { DwellerBatchOperations } from './DwellerBatchOperations';
