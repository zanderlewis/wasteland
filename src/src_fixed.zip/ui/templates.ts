// UI Templates for the Wasteland Save Editor - Re-exports from modular templates
export * from './templates/index';
